 ///
 /// @file    namespace1.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 11:42:00
 ///
 
#include <iostream>

using std::cout;
using std::endl;

namespace wd
{

int inumber = 1;

void display()
{
	printf("display()\n");
	std::cout << "display()" << std::endl;
}

}//end of namespace wd

 
void test00() 
{
	printf("number: %d\n", wd::inumber);
	wd::display();
} 

namespace wd
{

void show()
{
	cout << "wd::show()" << endl;
}

}//end of namespace wd

void test10()
{
	wd::show();
}
 
int main(void)
{
	test00();
	test10();
	return 0;
}
