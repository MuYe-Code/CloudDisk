 ///
 /// @file    namespace1.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 11:42:00
 ///
 
#include <iostream>

//第二种命名空间的使用方式: using编译指令
using namespace std;//std standard

//命名空间的定义
namespace wd
{

int number = 1;

void display()
{
	printf("display()\n");
	cout << "display()" << endl;
}

}//end of namespace wd

//假设不知道std空间中的实体
void cout()
{
	printf("test cout()\n");
}


//命名空间的使用语句
using namespace wd;
 
void test0() 
{
	printf("number: %d\n", number);
	display();
} 
 
int main(void)
{
	/* test0(); */
	cout();
	return 0;
}
