 ///
 /// @file    reference3.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 17:51:54
 ///
 
#include <iostream>
using std::cout;
using std::endl;


//高频考点: 引用与指针的区别？

//全局变量
int arr[5] = {1, 2, 3, 4, 5};

//引用作为函数的返回值，不会进行复制，
//节省开销
int & getValue(int idx)
{
	return arr[idx];
}

//不能返回一个局部变量的引用
int & func1()
{
	//number是一个局部变量
	//由于返回值是一个引用，
	//当return完成，func1函数退出时
	//number已经被销毁了, 实体已经消失，
	//那么引用也就没有啥意义了
	int number = 1;
	return number;
}

//不要轻易返回一个堆空间变量的引用，
//除非已经做好了内存回收的策略
int & func2()
{
	int * pint = new int(10);
	return *pint;
}

#if 0
MYSQL * conn;
MYSQL_RES * res;
mysql_close(conn);
#endif

 
void test0() 
{
	/* cout << func1() << endl; */

	cout << getValue(1) << endl;
	getValue(1) = 10;
	cout << "arr[1]:" << arr[1] << endl;

	int a = 1, b = 2;
	//完全救不回来的,一定会发生内存泄漏
	cout << func2() << endl;	
	int c = a + func2() + b;

	//可以救的回来
	int & ref = func2();
	cout << "ref:" << ref << endl;
	delete (&ref);//形式上没有对称,代码不够雅观
} 
 
int main(void)
{
	test0();
	return 0;
}
