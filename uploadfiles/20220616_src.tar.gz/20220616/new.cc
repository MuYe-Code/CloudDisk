 ///
 /// @file    new.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 16:42:21
 ///
 
#include <iostream>
using std::cout;
using std::endl;
 
void test0() 
{
	//只申请一个int型变量的空间
	int * pint = new int(10);
	cout << "*pint:" << *pint << endl;
 
	delete pint;//只回收一个

	//申请一个数组
	int * parr = new int[10];//不加小括号，没有初始化
	for(int i = 0; i < 10; ++i) {
		//parr[i] = 0;
		//cout << parr[i] << " ";
	}
	cout << endl << endl;
	
	//大力推荐加上小括号
	int * parr2 = new int[10]();//加了小括号，才会进行初始化
	for(int i = 0; i < 10; ++i) {
		cout << parr2[i] << " ";
	}
	cout << endl;

	//对于数组的回收，一定要加上[]，否则报错
	delete [] parr;//回收整个数组的空间
	delete [] parr2;
} 
 
int main(void)
{
	test0();
	return 0;
}
