 ///
 /// @file    const.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 16:20:33
 ///
 
#include <iostream>
using std::cout;
using std::endl;
 
void test0() 
{
	int number =1;
	cout << "number:" << number << endl;

	const int num = 2;
	//num = 3;//error
	
	const int num2;
 
	cout << "num2: " << num2 << endl;
} 
 
int main(void)
{
	test0();
	return 0;
}
