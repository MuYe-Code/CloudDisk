 ///
 /// @file    constPointer.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 16:25:57
 ///
 
#include <iostream>
using std::cout;
using std::endl;
typedef int * INT;
 
void test0() 
{
	int a = 1;
	int b = 10;

	int * p = &a;
	cout << "*p:" << *p << endl;//解引用
	*p = 11;
	p = &b;//改变指向
	cout << "*p:" << *p << endl;//解引用

	cout << endl;
	const int * p0 = &a; //常量指针, const关键字在*号的左边
	cout << "*p0:" << *p0 << endl;//解引用
	p0 = &b;//ok 可以改变指向
	*p0 = 100;//error  不能改变指针所指变量的值
	
	int const * p1 = &a;
	cout << "*p1:" << *p1 << endl;//解引用
	p1 = &b;//ok 可以改变指向
	*p1 = 100;//error

	int * const p2 = &a;//指针常量, const关键字在*号的右边
	cout << "*p2:" << *p2 << endl;//解引用
	p2 = &b;//error 不可以改变指向
	*p2 = 100;//ok  可以改变指针所指变量的值


	//两者都不能进行修改
	int const * const p3 = &a;
	p3 = &b;//error
	*p3 = 222;//error
} 
 
int main(void)
{
	test0();
	return 0;
}
