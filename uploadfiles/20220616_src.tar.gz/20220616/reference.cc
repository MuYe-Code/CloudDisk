 ///
 /// @file    reference.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 17:20:38
 ///
 
#include <iostream>
using std::cout;
using std::endl;
 
void test0() 
{
	int number = 1;
	//C的写法中，NULL 就是0
	//C++11的写法，空指针  
	int * p = nullptr;// 指针可以单独存在, 野指针
	//int & ref;//引用不能单独存在
	int & ref = number;//引用进行了初始化,绑定到number变量
	//一旦绑定之后，操作引用与操作变量本身是相同的
	
	cout << "&ref:" << &ref << endl
		 << "&number:" << &number << endl;
	ref = 10;
	cout << "ref:" << ref << endl
		 << "number:" << number << endl;
} 
 
int main(void)
{
	test0();
	return 0;
}
