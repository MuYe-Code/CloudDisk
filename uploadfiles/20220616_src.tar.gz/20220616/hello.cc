 ///
 /// @file    hello.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 11:21:23
 ///
 
#include <stdio.h>  //C标准库的头文件都是以.h结尾
#include <iostream> //C++标准库文件没有后缀, 
				    //原因在于C++标准库是以模板实现的

using namespace std;//引出了一个新的概念:命名空间, C语言中没有

int main(int argc, char *argv[]) {
	//stdout 标准输出
	//cout 是一个对象
	//<<  重定向/左移运算符
	//	  C++新增一个用法:输出流运算符 (本质上是一个函数)
	//endl  endline 回车
	//写法：链式编程
	int number = 1;
	cout << "hello,world, number:" << number <<  endl;
	return 0;
}
