 ///
 /// @file    testAnonymousEntity.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 15:17:35
 ///
 
#include <iostream>
using std::cout;
using std::endl;

extern int number;//声明是另外模块的变量(外部变量)

namespace {
extern int a_number;
void print();
}//end of anonymous namespace

//有名的命名空间

//extern int wd::number;//error
#if 1
namespace wd
{
extern int number;
void strcpy();//函数声明
}
#endif

 
void test00() 
{
	cout << "test00()" << endl;
	cout << "number:" << number << endl;
	//无法访问
	//cout << "a_number:" << ::a_number << endl;
	//::print();
	//
	//有名命名空间的实体都可以使用
	cout << "wd::number:" << wd::number << endl;
	//::print();
	wd::strcpy();
} 
 
int main(void)
{
	test00();
	return 0;
}
