 ///
 /// @file    reference2.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 17:31:19
 ///
 
#include <iostream>
using std::cout;
using std::endl;

#if 0
//值传递
void swap(int x, int y)
{
	int tmp = x;
	x = y;
	y = tmp;
}
#endif

//地址传递 --》 还是值传递
void swap(int * px, int * py)
{
	int tmp = *px;	
	*px = *py;
	*py = tmp;
}

//引用传递, 没有复制的开销，直接操作实参本身
//可以提高程序的执行效率
//参数形式：非const引用,是一个传入传出参数
void swap(int & x, int & y)
{
	int tmp = x;
	x = y;
	y = tmp;
}

//如果传递过来的参数，只做读操作，
//都要将其设计为const引用
void func(const int & x)
{
	//x = 10;
	cout << "x:" << x << endl;
}
 
void test0() 
{
	int a = 3, b = 4;
	cout << "a:" << a << endl 
		 << "b:" << b << endl << endl;

	swap(a, b);
	/* swap(&a, &b); */
	cout << "a:" << a << endl 
		 << "b:" << b << endl << endl;
 
	//常引用 不能修改所绑定的变量的值
	const int & ref = a;
	//ref = 1;//error

	int & ref2 = a;
	ref2 = 10;
} 
 
int main(void)
{
	test0();
	return 0;
}
