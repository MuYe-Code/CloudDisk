 ///
 /// @file    namespace1.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 11:42:00
 ///
 
#include <iostream>

//第三种命名空间的使用方式: using声明机制
using std::cout;// 只会引入某一个实体
using std::endl;

//命名空间的定义
//对于命名空间中定义的实体，不做缩进操作
namespace wd
{

int number = 1;

void display()
{
	printf("display()\n");
	cout << "display()" << endl;
}

namespace cteam
{
int number = 2;

void display()
{
	cout << "cteam: display()" << endl;
}

}//end of namespace cteam

}//end of namespace wd


void cout1()
{
	printf("test cout1()\n");
	printf("wd number:%d\n", wd::number);
	
	//嵌套使用
	wd::cteam::display();
	cout << endl;
	wd::display();
}

//命名空间的使用语句
using namespace wd;
 
void test0() 
{
	printf("number: %d\n", number);
	display();
} 
 
int main(void)
{
	/* test0(); */
	cout1();
	return 0;
}
