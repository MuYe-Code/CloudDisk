 ///
 /// @file    namespace1.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 11:42:00
 ///
 
#include <iostream>

//using namespace std;//std standard

namespace wd
{

int number = 1;

void display()
{
	printf("display()\n");
	std::cout << "display()" << std::endl;
}

}//end of namespace wd

 
void test0() 
{
	printf("number: %d\n", wd::number);
	wd::display();
} 
 
int main(void)
{
	test0();
	return 0;
}
