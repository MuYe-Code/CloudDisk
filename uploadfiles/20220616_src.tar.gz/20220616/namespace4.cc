 ///
 /// @file    namespace4.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 14:53:49
 ///
 
#include <stdio.h>
#include <string.h>
#include <iostream>
using std::cout;
using std::endl;


//匿名的命名空间
void test0() 
{
	::printf("hello,world\n");
	char str1[] = "wangdao";
	char str2[100] = {0};
	::strcpy(str2, str1);

	cout << "str2:" << str2 << endl;
} 

namespace wd
{
void strcpy()
{
	cout << "wd::strcpy()" << endl;
	char str1[] = "wangdao";
	char str2[100] = {0};
	::strcpy(str2, str1);
}
}//end of namespace wd

void test1()
{
	wd::strcpy();
}
 
int main(void)
{
	/* test0(); */
	test1();
	return 0;
}
