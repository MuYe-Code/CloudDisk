 ///
 /// @file    namespace4.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-06-16 14:53:49
 ///
 
#include <stdio.h>
#include <string.h>
#include <iostream>
using std::cout;
using std::endl;


//匿名的命名空间
void test0() 
{
	::printf("hello,world\n");
	char str1[] = "wangdao";
	char str2[100] = {0};
	::strcpy(str2, str1);

	cout << "str2:" << str2 << endl;
} 

namespace wd
{
int number = 100;
void strcpy()
{
	cout << "wd::strcpy()" << endl;
	char str1[] = "wangdao";
	char str2[100] = {0};
	::strcpy(str2, str1);
	printf("str2:%s\n", str2);
}
}//end of namespace wd

void test1()
{
	wd::strcpy();
}

//全局变量
int number = 10;
//static int number = 100;
//C语言中对于静态的变量和函数有什么样的特点？
//答: static的实体只能在本模块内部使用
static int s_number = 1;

static void show()
{
	cout << "show()" << endl;
}

//在匿名命名空间中添加实体
//其中的实体不能跨模块调用，只能在本模块内部使用
namespace 
{
//在匿名命名空间中的一个number, 不是全局变量number
//int number =2;//不能这样定义，因为与全局变量命名冲突，否则就有问题
int a_number = 100;

void print()
{
	cout << "print(), a_number:" << a_number << endl;
}

}//anonymous namespace

void test2()
{
	cout << "number:" << ::number << endl;
	print();
}
 
#if 0
int main(void)
{
	/* test0(); */
	/* test1(); */
	test2();
	return 0;
}
#endif
